import { Hero } from './hero';

export var HEROES: Hero[] = [
	{"id": 11, "name": "Mr. Nice", "color": "#AAAAAA", "dob": new Date("1980/01/01")},
	{"id": 12, "name": "Narco", "color": "#BBBBBB", "dob": new Date("1990/02/01")},
	{"id": 13, "name": "Bombasto", "color": "#CCCCCC", "dob": new Date("1995/03/01")},
	{"id": 14, "name": "Celeritas", "color": "#DDDDDD", "dob": new Date("1962/04/01")},
	{"id": 15, "name": "Magneta", "color": "#EEEEEE", "dob": new Date("1930/05/01")},
	{"id": 16, "name": "RubberMan", "color": "#999999", "dob": new Date("1950/05/01")},
	{"id": 17, "name": "Dynama", "color": "#999900", "dob": new Date("1944/07/01")},
	{"id": 18, "name": "Dr IQ", "color": "#9999AA", "dob": new Date("1978/08/01")},
	{"id": 19, "name": "Magma", "color": "#555500", "dob": new Date("1989/09/01")},
	{"id": 20, "name": "Tornado", "color": "#5555FF", "dob": new Date("1980/10/01")}
];


/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/

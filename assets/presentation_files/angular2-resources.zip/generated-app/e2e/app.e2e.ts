import { GeneratedAppPage } from './app.po';

describe('generated-app App', function() {
  let page: GeneratedAppPage;

  beforeEach(() => {
    page = new GeneratedAppPage();
  })

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('generated-app works!');
  });
});

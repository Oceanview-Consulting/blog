export class GeneratedAppPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('generated-app-app h1')).getText();
  }
}

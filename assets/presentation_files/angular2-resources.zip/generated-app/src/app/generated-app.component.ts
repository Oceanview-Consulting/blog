import { Component } from '@angular/core';

@Component({
  moduleId: module.id,
  selector: 'generated-app-app',
  templateUrl: 'generated-app.component.html',
  styleUrls: ['generated-app.component.css']
})
export class GeneratedAppAppComponent {
  title = 'generated-app works!';
}

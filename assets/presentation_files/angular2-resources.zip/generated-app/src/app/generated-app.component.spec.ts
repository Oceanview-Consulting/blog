import {
  beforeEachProviders,
  describe,
  expect,
  it,
  inject
} from '@angular/core/testing';
import { GeneratedAppAppComponent } from '../app/generated-app.component';

beforeEachProviders(() => [GeneratedAppAppComponent]);

describe('App: GeneratedApp', () => {
  it('should create the app',
      inject([GeneratedAppAppComponent], (app: GeneratedAppAppComponent) => {
    expect(app).toBeTruthy();
  }));

  it('should have as title \'generated-app works!\'',
      inject([GeneratedAppAppComponent], (app: GeneratedAppAppComponent) => {
    expect(app.title).toEqual('generated-app works!');
  }));
});

export {environment} from './environment';
export {GeneratedAppAppComponent} from './generated-app.component';

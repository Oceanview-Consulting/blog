﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleSample
{
    public class Dog
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int OwnerId { get; set; }
        public string Breed { get; set; }

        public DogSize Size { get; set; }
    }

    public enum DogSize
    {
        Pocket,
        Bag,
        AnkleBiter,
        Normal,
        ToddlerJoustingPossible,
        ThatIsAHorseNotADog
    }

    public class OwnerDogDto : Dog
    {
        public Person Owner { get; set; }
    }
}

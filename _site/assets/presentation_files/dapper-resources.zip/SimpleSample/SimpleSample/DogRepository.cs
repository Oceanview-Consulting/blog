﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;

namespace SimpleSample
{
    public class DogRepository
    {
        private string _connectionString;

        public DogRepository(string connectionString)
        {
            _connectionString = connectionString;
        }

        public IEnumerable<Dog> Get()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                return connection.Query<Dog>("SELECT * FROM Dogs");
            }
        }

        public IEnumerable<Dog> FindBySize(DogSize size)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                return connection.Query<Dog>("SELECT * FROM Dogs WHERE Size = @Size", new { Size = size });
            }
        }

        public IEnumerable<Dog> LookupByIds(params int[] ids)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                return connection.Query<Dog>("SELECT * FROM Dogs WHERE Id IN @Ids", new { Ids = ids });
            }
        }

        public int DeleteSamples()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                return connection.Execute("DELETE FROM Dogs WHERE Name = 'Sample'");
            }
        }

        public IEnumerable<IGrouping<Person, Dog>> AllGroupedByOwner()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var query = "SELECT * FROM People JOIN Dogs ON Dogs.OwnerId = People.Id";

                var records = connection.Query<Person, OwnerDogDto, OwnerDogDto>(query, (owner, dog) => { dog.Owner = owner; return dog; });

                return records.GroupBy(d => d.Owner, new DogComparator());
            }
        }

        public IEnumerable<IGrouping<Person, Dog>> AllGroupedByOwnerBetter()
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            {
                var query = @"
                    SELECT * FROM People
                    SELECT * FROM Dogs";

                using (var resultSet = connection.QueryMultiple(query))
                {
                    var owners = resultSet.Read<Person>().ToList();
                    var dogs = resultSet.Read<Dog>().ToList();

                    return dogs.GroupBy(d => owners.FirstOrDefault(o => o.Id == d.OwnerId));
                }
            }
        }

        public int Insert(Dog dog)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                return connection.Execute("INSERT INTO Dogs (Name, Breed, Size, OwnerId) VALUES (@Name, @Breed, @Size, @OwnerId)", dog);
            }
        }

        public int InsertRange(IEnumerable<Dog> dogs)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                return connection.Execute("INSERT INTO Dogs (Name, Breed, Size, OwnerId) VALUES (@Name, @Breed, @Size, @OwnerId)", dogs);
            }
        }
        //This is poorly named, it should be Person, not dog. 
        //That said, I'm leaving it for easier reference in the video.
        private class DogComparator : IEqualityComparer<Person>
        {
            public bool Equals(Person x, Person y)
            {
                if(x == null || y == null)
                {
                    return false;
                }

                return x.Id == y.Id;
            }

            public int GetHashCode(Person obj)
            {
                return obj.Id;
            }
        }
    }
}

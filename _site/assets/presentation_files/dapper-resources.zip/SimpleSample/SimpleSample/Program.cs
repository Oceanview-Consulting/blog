﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.IO;

namespace SimpleSample
{
    class Program
    {
        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.SetData("DataDirectory", Path.GetFullPath(Path.Combine(Environment.CurrentDirectory, @"..\..\")));
            var dogRepo = new DogRepository(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Dogs.mdf;Integrated Security=True");

            SimpleSelect(dogRepo);
            //WithParameters(dogRepo);
            //ParameterListExpansion(dogRepo);
            //MultiQuery(dogRepo);
            //MultipleResultSets(dogRepo);

            InsertDog(dogRepo);
            InsertDogs(dogRepo, 5);

            SimpleSelect(dogRepo);

            DeleteAllSamples(dogRepo);

            Console.WriteLine("Press enter to exit...");
            Console.ReadLine();
        }

        private static void DeleteAllSamples(DogRepository dogRepo)
        {
            Console.WriteLine("==== Deleting all sample dogs ====");
            var deleteCount = dogRepo.DeleteSamples();

            Console.WriteLine("==== {0} dogs deleted ====", deleteCount);
        }

        private static void InsertDogs(DogRepository dogRepo, int num)
        {
            Console.WriteLine("==== Inserting {0} new dogs ====", num);
            var dogs = new List<Dog>();
            for (int x = 1; x <= num; x++)
            {
                dogs.Add(CreateSampleDog());
            }

            dogRepo.InsertRange(dogs);
        }

        private static void InsertDog(DogRepository dogRepo)
        {
            Console.WriteLine("==== Inserting a new dog ====");
            dogRepo.Insert(CreateSampleDog());
        }
        
        private static Dog CreateSampleDog()
        {
            return new Dog()
            {
                Name = "Sample",
                Breed = "Unknown",
                Size = DogSize.Normal,
                OwnerId = 1
            };
        }

        private static void ParameterListExpansion(DogRepository dogRepo)
        {
            Console.WriteLine("==== Selecting dogs 1, 3, and 4 ====");
            foreach (var dog in dogRepo.LookupByIds(1, 3, 4)) 
            {
                WriteDog(dog);
            }
        }

        private static void WithParameters(DogRepository dogRepo)
        {
            Console.WriteLine("==== Selecting dogs of size 'ToddlerJoustingPossible' ====");
            foreach (var dog in dogRepo.FindBySize(DogSize.ToddlerJoustingPossible))
            {
                WriteDog(dog);
            }
        }

        private static void SimpleSelect(DogRepository dogRepo)
        {
            Console.WriteLine("==== Selecting all dogs ====");
            foreach (var dog in dogRepo.Get())
            {
                WriteDog(dog);
            }
        }

        private static void MultipleResultSets(DogRepository dogRepo)
        {
            Console.WriteLine("==== Selecting all dogs grouped by owner using multiple result sets ====");
            var groups = dogRepo.AllGroupedByOwnerBetter();

            foreach (var group in groups)
            {
                WritePerson(group.Key);
                foreach (var dog in group)
                {
                    WriteDog(dog);
                }
            }
        }

        private static void MultiQuery (DogRepository dogRepo)
        {
            Console.WriteLine("==== Selecting all dogs, grouped by owner using a multimapped query ====");
            var groups = dogRepo.AllGroupedByOwner();

            foreach (var group in groups)
            {
                WritePerson(group.Key);
                foreach (var dog in group)
                {
                    WriteDog(dog);
                }
            }
        }

        private static void WriteDog(Dog dog)
        {
            Console.WriteLine("Dog - Id: {4}, Name: {0}; Breed: {1}, Size: {2}, OwnerId: {3}", dog.Name, dog.Breed, dog.Size, dog.OwnerId, dog.Id);
        }

        private static void WritePerson(Person person)
        {
            Console.WriteLine("Person - Id: {1}, Name: {0}", person.Name, person.Id);
        }
    }
}
